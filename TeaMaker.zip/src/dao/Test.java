package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Test {
	
	
	public static void main(String[] args) {
		try {
			Connection con = null;
			java.sql.Statement st = null;
			ResultSet rs = null;

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/",
					"root", "root");


			st = con.createStatement();
			rs = st.executeQuery("SHOW DATABASES");
			rs = st.executeQuery("USE TEAMMAKER");
			rs = st.executeQuery("SHOW TABLES");
			rs = st.executeQuery("DESC MEMBER");

			if (st.execute("DESC MEMBER")) {
				rs = st.getResultSet();
			}

			while (rs.next()) {
				String str = rs.getNString(1);
				System.out.println(str);
			}
		} catch (SQLException sqex) {
			System.out.println("SQLException: " + sqex.getMessage());
			System.out.println("SQLState: " + sqex.getSQLState());
		}

	}
		
}
