package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import vo.Member;

public class SignUpDao {

	DataSource ds;
	
	public void setDataSource(DataSource ds){
		this.ds = ds;
	}
	
	
	public Member signUpGetInfo(String name, String passwd, String phonenumber, String tech, String email) throws Exception {

//		PreparedStatement stmt = null;
//		Connection connection = null;
//		java.sql.Statement st = null;
//		
//		
//		
//		try {
//            // Get DataSource
//            Context initContext  = new InitialContext();
//            Context envContext  = (Context)initContext.lookup("java:/comp/env");
//            DataSource dataSource = (DataSource)envContext.lookup("jdbc/TeaMaker");
//            connection = dataSource.getConnection();
//             
//        } catch (NamingException e) {
//            e.printStackTrace();
//        }

		try {
			
			java.sql.PreparedStatement pstmt = null;
			String sql;
			Connection con = null;
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/teammaker", "root", "root");

			
			
			sql = "INSERT INTO MEMBER (Member_name, Member_password, Member_phonenum, Member_tech, Member_email)";
			sql += "VALUES (?,?,?,?,?)";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, passwd);
			pstmt.setString(3, phonenumber);
			pstmt.setString(4, tech);
			pstmt.setString(5, email);

			pstmt.executeUpdate();
			pstmt.close();
			
			con.close();
			
		}  catch (SQLException sqex) {
			System.out.println("SQLException: " + sqex.getMessage());
			System.out.println("SQLState: " + sqex.getSQLState());
		}
		return null;
		
	}
}