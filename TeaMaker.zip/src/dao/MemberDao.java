package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import vo.Member;

public class MemberDao  {
	
	DataSource ds;
	
	public void setDataSource(DataSource ds){
		this.ds = ds;
	}
	
	public Member login(String email, String password) throws Exception{

		PreparedStatement stmt = null;
		ResultSet rs = null;
		Connection connection = null;

		try {
			connection = ds.getConnection();
			stmt = connection
					.prepareStatement("SELECT Member_name, Member_email,Member_tech FROM member"
							+ " WHERE Member_email=? AND Member_password=?");
			stmt.setString(1, email);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
		
			if (rs.next()) {
				return null;
			} else {
				return null;
			}
		} catch(Exception e) {
			throw e;

		} finally {
			try { if (rs != null)	rs.close();} catch (Exception e) {}
			try { if (stmt != null) stmt.close();} catch (Exception e) {}
			try { if(connection != null) connection.close();} catch(Exception e){}
		}
			

	}
	
	public void insert(Member member){
		
	}
	
	public Member update(int no){
		return new Member();
	}
	
	public void delete(Member member){
		
	}
	
	
}
