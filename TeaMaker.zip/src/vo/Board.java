package vo;

import java.util.Date;

public class Board {
	protected int Board_no;
	protected int Member_no;
	protected String title;
	protected String context;
	protected Date createDate;
	
	
	/* �����Ͱ� ��������*/
	public int getBoardno() {
		return Board_no;
	}
	
	public int getMemberno() {
		return Member_no;
	}
	
	public String getTitle() {
		return title;
	}
	
	public String getContext() {
		return context;
	}
	
	public Date getDate() {
		return createDate;
	}
	
	
	/*�����Ͱ� �ٲٱ�*/
	public Board setTitle(String title) {
		this.title = title;
		return this;
	}
	
	public Board setContext(String context) {
		this.context = context;
		return this;
	}

}
