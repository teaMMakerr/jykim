package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

import dao.MemberDao;
import dao.SignUpDao;
import vo.Member;

@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		try {
			req.setCharacterEncoding("utf-8");

			String name = req.getParameter("username");
			String passwd = req.getParameter("password");
			String phonenumber = req.getParameter("phonenum");
			String tech = req.getParameter("tech");
			String email = req.getParameter("email");
			
			ServletContext sc = this.getServletContext();
			SignUpDao signUpDao = new SignUpDao();
			signUpDao = (SignUpDao) sc.getAttribute("signUpDao");
			Member member = new Member();
			member = signUpDao.signUpGetInfo(name, passwd, phonenumber, tech, email);
//			member.setMember_name(name);
//			member.setMember_password(passwd);
//			member.setMember_phonenum(phonenumber);
//			member.setMember_tech(tech);
//			member.setMember_email(email);
			

			if (member != null) {
				HttpSession session = req.getSession();
				session.setAttribute("member", member);
				resp.sendRedirect("SignUpResult.jsp");

			} 
//			else {
//				RequestDispatcher rd = req.getRequestDispatcher("/SignUpServlet");
//				rd.forward(req, resp);
//			}

		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

}