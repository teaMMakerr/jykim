package kr.tm.teammaker.vo;

public class TMem {
	
	protected String Member_email;
	protected String Team_id;
	
	public String getTeam_id(){
		return Team_id;
	}
	public String getMember_email() {
		return Member_email;
	}
	public TMem setTeam_id(String Team_id) {
		this.Team_id = Team_id;
		return this;
	}
	public TMem setMember_email(String Member_email) {
		this.Member_email = Member_email;
		return this;
	}

}
