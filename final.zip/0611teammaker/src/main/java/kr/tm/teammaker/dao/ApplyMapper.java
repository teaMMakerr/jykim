package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.Apply;

public interface ApplyMapper {
	public void insert(String Board_id, String Member_email);
	public ArrayList<String> selectList(String Board_id);
	public ArrayList<Apply> getNotices();
}