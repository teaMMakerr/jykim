package kr.tm.teammaker.vo;

public class Apply {
	
	protected int Board_id;
	protected String Member_email;
	
	public int getBoard_id() {
		return Board_id;
	}
	
	public String getMember_email() {
		return Member_email;
	}
	
	public Apply setBoard_id(int Board_id) {
		this.Board_id = Board_id;
		return this;
	}
	public Apply setMember_email(String Member_email) {
		this.Member_email = Member_email;
		return this;
	}

}
