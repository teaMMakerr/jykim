package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.Board;

public interface BoardMapper {
	Board selectOne(int Bid, String email) throws Exception;
	void insert(Board board)throws Exception;
	ArrayList<Board> getNotices();
	void delete(int Board_id)throws Exception;
}
