package kr.tm.teammaker.vo;

import java.util.Date;

public class TeamBoard {

	protected int TBoard_id;
	protected String Member_email;
	protected String TBoard_title;
	protected String TBoard_context;
	protected Date TBoard_date;
	protected String Team_id;

	public String getTeam_id() {
		return Team_id;
	}

	public int getTBoard_id() {
		return TBoard_id;
	}

	public String getMember_email() {
		return Member_email;
	}

	public String getTBoard_title() {
		return TBoard_title;
	}

	public String getTBoard_context() {
		return TBoard_context;
	}

	public Date getTBoard_date() {
		return TBoard_date;
	}

	public TeamBoard setTBoard_title(String TBoard_title) {
		this.TBoard_title = TBoard_title;
		return this;
	}

	public TeamBoard setMember_email(String Member_email) {
		this.Member_email = Member_email;
		return this;
	}

	public TeamBoard setTBoard_context(String TBoard_context) {
		this.TBoard_context = TBoard_context;
		return this;
	}

	public TeamBoard setTBoard_id(int TBoard_id) {
		this.TBoard_id = TBoard_id;
		return this;
	}

	public TeamBoard setTeam_id(String Team_id) {
		this.Team_id = Team_id;
		return this;
	}

	public TeamBoard setTBoard_date(Date TBoard_date) {
		this.TBoard_date = TBoard_date;
		return this;
	}

}
