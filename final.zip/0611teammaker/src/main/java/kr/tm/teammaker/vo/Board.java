package kr.tm.teammaker.vo;

import java.util.Date;

public class Board {
	protected int Board_id;
	protected String Member_email;
	protected String Board_title;
	protected String Board_context;
	protected Date Board_date;
	protected String Team_id;
	
	

	public String getTeam_id(){
		return Team_id;
	}
	
	public int getBoard_id() {
		return Board_id;
	}
	
	public String getMember_email() {
		return Member_email;
	}
	
	public String getBoard_title() {
		return Board_title;
	}
	
	public String getBoard_context() {
		return Board_context;
	}
	
	public Date getBoard_date() {
		return Board_date;
	}
	
	public Board setBoard_title(String Board_title) {
		this.Board_title = Board_title;
		return this;
	}
	
	public Board setMember_email(String Member_email) {
		this.Member_email = Member_email;
		return this;
	}

	public Board setBoard_context(String Board_context) {
		this.Board_context = Board_context;
		return this;
	}
	
	public Board setBoard_id(int Board_id) {
		this.Board_id = Board_id;
		return this;
	}
	
	public Board setTeam_id(String Team_id) {
		this.Team_id = Team_id;
		return this;
	}
	
	public Board setBoard_date(Date Board_date){
		this.Board_date = Board_date;
		return this;
	}
	
}
