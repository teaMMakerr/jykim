package kr.tm.teammaker.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.tm.teammaker.vo.Member;

@Repository
public class MemberDaoService implements MemberDao {

	@Autowired
	SqlSession sqlSession;

	@Override
	public Member selectOne(String email, String password) throws Exception {

		HashMap<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("email", email);
		paramMap.put("password", password);

		Member member = sqlSession.selectOne("kr.tm.teammaker.dao.MemberMapper.selectOne", paramMap);

		return member;

	}

	@Override
	public void insert(Member member) throws Exception {
		sqlSession.insert("kr.tm.teammaker.dao.MemberMapper.insert", member);
	}

	@Override
	public ArrayList<Member> getMembers() {
		ArrayList<Member> adminMember = new ArrayList<Member>();
		// sqlSession�� ���Ͽ� �����Ѵ�.
		MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
		// getMember()�� �޼ҵ���� mapper.mxl�� id�� �����ؾ��Ѵ�.
		adminMember = memberMapper.getMembers();

		return adminMember;
	}

	@Override
	public void delete(String email)throws Exception {
		MemberMapper memberMapper = sqlSession.getMapper(MemberMapper.class);
		memberMapper.delete(email);
	}

}
