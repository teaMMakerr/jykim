package kr.tm.teammaker.dao;

import java.util.ArrayList;

import org.springframework.transaction.annotation.Transactional;

import kr.tm.teammaker.vo.Member;


public interface MemberDao  {
	public Member selectOne(String email, String password) throws Exception;
	public void insert(Member member)throws Exception;
	public ArrayList<Member> getMembers();
	public void delete(String email)throws Exception;
}



