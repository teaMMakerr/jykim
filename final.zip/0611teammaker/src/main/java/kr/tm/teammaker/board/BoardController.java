package kr.tm.teammaker.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import kr.tm.teammaker.dao.BoardDaoService;
import kr.tm.teammaker.dao.TMemDaoService;
import kr.tm.teammaker.dao.ApplyDaoService;
import kr.tm.teammaker.vo.Board;
import kr.tm.teammaker.vo.TMem;
import kr.tm.teammaker.vo.TeamBoard;
import kr.tm.teammaker.vo.Apply;

@Controller
public class BoardController {
	
	
	@Autowired
	private BoardDaoService boardDaoService;
	
	@Autowired
	private ApplyDaoService applyDaoService;
	
	@Autowired
	private TMemDaoService tmemDaoService;
	
	
	
	@RequestMapping(value = "/board/boardIndex.do", method = RequestMethod.GET)
	public String boardIndex(){
		return "board/boardIndex";
	}
	
	@RequestMapping(value = "/board/board.do", method = RequestMethod.GET)
	public String board(){
		return "board";
	}
	
	@RequestMapping(value = "/board/board.do", method = RequestMethod.POST)
	public ModelAndView POSTboard(HttpServletRequest req,Locale locale, Model model){
		
		String Bid = req.getParameter("Board_id");
		int Board_id = Integer.parseInt(Bid)-1;
		
		model.addAttribute("Board_id", Board_id);
		req.setAttribute("Board_id", Board_id);
		
	
	
		ArrayList<String> applyMember= applyDaoService.selectList(Bid);
		
		model.addAttribute("applicant", applyMember);
		
        ModelAndView board = new ModelAndView();

        List<Board> boardList = boardDaoService.getNotices();
        board.addObject("board", boardList);
        board.addObject("applyMember",applyMember);
        board.setViewName("board");
        
        
        
        return board;
	}
	
	
	@RequestMapping(value = "/board/boardNotice.do", method = RequestMethod.GET)
    public ModelAndView boardNotice(Locale locale, Model model) {
 
        // view ȭ���� main.jsp�� DB�κ��� �о�� �����͸� �����ش�.
        ModelAndView boardNotice = new ModelAndView();
        
        //addObject view�� �Ѿ�� ������
        List<Board> boardList = boardDaoService.getNotices();
        boardNotice.addObject("boardNotice", boardList);
        boardNotice.setViewName("boardNotice");
        
        return boardNotice;
    }
	
	
	@RequestMapping(value = "/board/makeTeam.do", method = RequestMethod.POST)
	public String makeTeam(HttpServletRequest req,Model model) throws Exception{
		
		TMem TMem = new TMem();	
		String Member_email = req.getParameter("Member_email");
		String Team_id = req.getParameter("Team_id");
		String Admin = req.getParameter("Admin");
		
		System.out.println(Team_id);
		

		if(Member_email.equals(Admin)){
			
			tmemDaoService.insert(TMem, Member_email, Team_id);
			return "makeTeam";
			
		}else{
			
			System.out.println("you are not a team leader");

		return "/board/boardIndex";
		}
	}
	
	@RequestMapping(value = "/board/boardWrite.do", method = RequestMethod.GET)
	public String boardWrite(){
		return "board/boardWrite";
	}
	
	@RequestMapping(value = "/board/Apply.do", method = RequestMethod.POST)
	public String Apply(Locale locale, Model model,HttpServletRequest req){
		
		String member = req.getParameter("Member_email");
		String Board_id = req.getParameter("Board_id");
		applyDaoService.insert(req.getParameter("Board_id"), req.getParameter("Member_email"));
		
		model.addAttribute("member", member);
		model.addAttribute("Board_id", Board_id);
		
		return "/board/boardIndex";
	}
	
	@RequestMapping(value = "/board/intro.do", method = RequestMethod.GET)
	public String intro(){
		return "board/intro";
	}
	


}
