package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.TeamBoard;

public interface TeamBoardMapper {
	void insert(TeamBoard teamBoard, String Team_id, String TBoard_title, String TBoard_context, String Member_email, int TBoard_id)throws Exception;
	ArrayList<TeamBoard> getNotices(String Team_id);
}
