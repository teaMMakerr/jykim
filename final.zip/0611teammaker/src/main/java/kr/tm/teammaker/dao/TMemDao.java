package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.TMem;

public interface TMemDao {
	public ArrayList<TMem> getNotices(String Team_id);
	public void insert(TMem TMem, String Member_email, String Team_id)throws Exception;
	public String selectOne(String Member_email) throws Exception;
}
