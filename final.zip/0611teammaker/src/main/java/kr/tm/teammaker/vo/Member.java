package kr.tm.teammaker.vo;

public class Member {

	private String Member_phonenum;
	private String Member_name;
	private String Member_password;
	private String Member_email;
	private String Member_tech;
	
	public String getMember_name(){
		return Member_name;
	};
	public Member setMember_name(String Member_name){
		this.Member_name = Member_name;
		return this;
	}
	
	public String getMember_password(){
		return Member_password;
	};
	public Member setMember_password(String Member_password){
		this.Member_password = Member_password;
		return this;
	}
	
	
	public String getMember_phonenum(){
		return Member_phonenum;
	}
	public Member setMember_phonenum(String Member_phonenum){
		this.Member_phonenum = Member_phonenum;
		return this;
	}

	
	public String getMember_tech(){
		return Member_tech;
	};
	public Member setMember_tech(String Member_tech){
		this.Member_tech = Member_tech;
		return this;
	}
	
	
	public String getMember_email(){
		return Member_email;
	};
	public Member setMember_email(String Member_email){
		this.Member_email = Member_email;
		return this;
	}

	
	
}
