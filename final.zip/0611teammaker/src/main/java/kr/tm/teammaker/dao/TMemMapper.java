package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.TMem;

public interface TMemMapper {
	ArrayList<TMem> getNotices(String Team_id);
	void insert(TMem TMem, String Member_email, String Team_id)throws Exception;
	String selectOne(String Member_email) throws Exception;

}
