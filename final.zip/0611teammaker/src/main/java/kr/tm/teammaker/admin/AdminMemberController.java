package kr.tm.teammaker.admin;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.tm.teammaker.dao.MemberDaoService;
import kr.tm.teammaker.vo.Member;

@Controller
public class AdminMemberController {

	@Autowired
	private MemberDaoService memberDaoService;

	@RequestMapping(value = "/admin/adminMember.do", method = RequestMethod.GET)
	public ModelAndView admin(Locale locale, Model model) {

		ModelAndView adminMember = new ModelAndView();

		List<Member> memberList = memberDaoService.getMembers();
		adminMember.addObject("adminMember", memberList);
		adminMember.setViewName("adminMember");

		return adminMember;
	}

	
	@RequestMapping(value = "/admin/delete.do", method = RequestMethod.POST)
	public String delete(HttpServletRequest req, @RequestParam String member_email ,Locale locale, Model model) {

		try {
			
			Member member = new Member();
			member.setMember_email(member_email);
			memberDaoService.delete(member_email);

			
		}catch (Exception e){}
		
		ModelAndView adminMember = new ModelAndView();

		List<Member> memberList = memberDaoService.getMembers();
		adminMember.addObject("adminMember", memberList);
		adminMember.setViewName("adminMember");

		return "/admin/adminIndex";
	}
}
