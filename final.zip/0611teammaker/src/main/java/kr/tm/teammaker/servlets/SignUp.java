package kr.tm.teammaker.servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import kr.tm.teammaker.dao.MemberDao;
import kr.tm.teammaker.vo.Member;

@Component("/signUp")
public class SignUp extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		try {
			req.setCharacterEncoding("utf-8");
			
			ServletContext sc = this.getServletContext();
			MemberDao memberDao = (MemberDao) sc.getAttribute("memberDao");
			
			memberDao.insert(new Member()
	        .setMember_name(req.getParameter("username"))
	        .setMember_password(req.getParameter("password"))
	        .setMember_phonenum(req.getParameter("phonenum"))
	        .setMember_tech(req.getParameter("tech"))
	        .setMember_email(req.getParameter("email")));

	      resp.sendRedirect("login");

		} catch (Exception e) {throw new ServletException(e); }}}



