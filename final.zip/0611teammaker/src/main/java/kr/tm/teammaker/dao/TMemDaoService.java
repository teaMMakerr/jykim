package kr.tm.teammaker.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.tm.teammaker.dao.TMemDao;
import kr.tm.teammaker.vo.Board;
import kr.tm.teammaker.vo.Member;
import kr.tm.teammaker.vo.TMem;

@Repository
public class TMemDaoService implements TMemDao {
	
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public String selectOne(String Member_email) throws Exception {
		

		String TMem = sqlSession.selectOne("kr.tm.teammaker.dao.TMemMapper.selectOne", Member_email);

		return TMem;

	}
	

	@Override
    public ArrayList<TMem> getNotices(String Team_id) {
        
		ArrayList<TMem> TMem = new ArrayList<TMem>();
        //sqlSession�� ���Ͽ� �����Ѵ�.
        TMemMapper TMemMapper = sqlSession.getMapper(TMemMapper.class);
        //getMember()�� �޼ҵ���� mapper.mxl�� id�� �����ؾ��Ѵ�.
        TMem = TMemMapper.getNotices(Team_id);
        
        return TMem;
    }

	@Override
	public void insert(TMem TMem, String Member_email, String Team_id) throws Exception {

		HashMap<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("Member_email", Member_email);
		paramMap.put("Team_id", Team_id);
		paramMap.put("TMem", "TMem");
		
		sqlSession.insert("kr.tm.teammaker.dao.TMemMapper.insert", paramMap);
	}

}
