package kr.tm.teammaker.dao;

import java.util.ArrayList;

import kr.tm.teammaker.vo.Member;

public interface MemberMapper {
	Member selectOne(String email, String password) throws Exception;
	void insert(Member member)throws Exception;
	ArrayList<Member> getMembers();
	void delete(String email)throws Exception;
}
