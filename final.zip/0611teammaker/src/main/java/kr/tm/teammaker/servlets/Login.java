package kr.tm.teammaker.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;


import javax.servlet.http.HttpSession;

import kr.tm.teammaker.dao.MemberDao;
import kr.tm.teammaker.vo.Member;


public class Login extends HttpServlet {

//	@Override
//	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
//			throws ServletException, IOException {
//		// TODO Auto-generated method stub
//	    RequestDispatcher rd = req.getRequestDispatcher("/auth/LogInForm.jsp");
//	    rd.forward(req, resp);
//	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		try{

	     ServletContext sc = this.getServletContext();
		 MemberDao memberDao = (MemberDao)sc.getAttribute("memberDao");
	      
	     Member member = memberDao.selectOne( req.getParameter("Member_email"), 
	    		  							req.getParameter("Member_password"));
	     
	     if (member != null) {
	         HttpSession session = req.getSession();
	         session.setAttribute("member", member);
	         resp.sendRedirect("/");

	       } else {
	         RequestDispatcher rd = req.getRequestDispatcher("/auth/LogInFail.jsp");
	         rd.forward(req, resp);
	       }
	      
		} catch (Exception e){
			throw new ServletException(e);
		}

	}

}
