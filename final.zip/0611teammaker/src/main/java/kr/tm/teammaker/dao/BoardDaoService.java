package kr.tm.teammaker.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.tm.teammaker.vo.Board;
import kr.tm.teammaker.vo.Member;

@Repository
public class BoardDaoService implements BoardDao {
	
	@Autowired
	SqlSession sqlSession;
	
	public Board selectOne(int Bid, String email) throws Exception {

		HashMap<Integer, String> paramMap = new HashMap<Integer, String>();
		paramMap.put(Bid, email);
		
		Board board = sqlSession.selectOne(
				"kr.tm.teammaker.dao.BoardMapper.selectOne", paramMap);

		return board;

	}
	

	public void insert(Board board) throws Exception {
		sqlSession.insert("kr.tm.teammaker.dao.BoardMapper.insert", board);
	}

	@Override
    public ArrayList<Board> getNotices() {
        ArrayList<Board> adminBoard = new ArrayList<Board>();
        //sqlSession�� ���Ͽ� �����Ѵ�.
        BoardMapper boardMapper = sqlSession.getMapper(BoardMapper.class);
        //getMember()�� �޼ҵ���� mapper.mxl�� id�� �����ؾ��Ѵ�.
        adminBoard = boardMapper.getNotices();
        
        return adminBoard;
    }
	
	@Override
	public void delete(int Board_id)throws Exception {
		BoardMapper boardMapper = sqlSession.getMapper(BoardMapper.class);
		boardMapper.delete(Board_id);
	}
	
	
}
