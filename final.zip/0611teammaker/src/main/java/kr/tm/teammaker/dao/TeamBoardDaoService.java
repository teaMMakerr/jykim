package kr.tm.teammaker.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.tm.teammaker.vo.TeamBoard;

@Repository
public class TeamBoardDaoService {
	
	@Autowired
	SqlSession sqlSession;
	

	

	public void insert(TeamBoard teamBoard, String Team_id, String TBoard_title, String TBoard_context, String Member_email, int TBoard_id) throws Exception {
		
		String Bid = String.valueOf(TBoard_id);
		
		HashMap<String, String> paramMap = new HashMap<String,String>();
		paramMap.put("Team_id", Team_id);
		paramMap.put("Board_title", TBoard_title);
		paramMap.put("Board_context", TBoard_context);
		paramMap.put("Member_email", Member_email);
		paramMap.put("Board_id", Bid);
		paramMap.put("teamBoard","teamBoard");
		
		
		sqlSession.insert("kr.tm.teammaker.dao.TeamBoardMapper.insert", paramMap);

	}
	

	public ArrayList<TeamBoard> getNotices(String Team_id){
        ArrayList<TeamBoard> teamBoardNotice = new ArrayList<TeamBoard>();
        //sqlSession�� ���Ͽ� �����Ѵ�.
        TeamBoardMapper teamBoardMapper = sqlSession.getMapper(TeamBoardMapper.class);
        //getMember()�� �޼ҵ���� mapper.mxl�� id�� �����ؾ��Ѵ�.
        teamBoardNotice = teamBoardMapper.getNotices(Team_id);
        
        return teamBoardNotice;
    }
	
}
