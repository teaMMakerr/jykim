package kr.tm.teammaker.admin;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.tm.teammaker.dao.BoardDaoService;
import kr.tm.teammaker.dao.MemberDaoService;
import kr.tm.teammaker.vo.Board;
import kr.tm.teammaker.vo.Member;

@Controller
public class AdminBoardController {

	@Autowired
	private BoardDaoService boardDaoService;
	
	@RequestMapping(value = "/admin/adminBoard.do", method = RequestMethod.GET)
    public ModelAndView admin(Locale locale, Model model) {
 
        // view ȭ���� main.jsp�� DB�κ��� �о�� �����͸� �����ش�.
        ModelAndView adminBoard = new ModelAndView();
        
        //addObject view�� �Ѿ�� ������
        List<Board> boardList = boardDaoService.getNotices();
        adminBoard.addObject("adminBoard", boardList);
        adminBoard.setViewName("adminBoard");
        
        return adminBoard;
    }
	
	@RequestMapping(value = "/admin/boardDelete.do", method = RequestMethod.POST)
	public String delete(HttpServletRequest req, @RequestParam int Board_id ,Locale locale, Model model) {

		try {
			
			Board board = new Board();
			board.setBoard_id(Board_id);
			boardDaoService.delete(Board_id);

			
		}catch (Exception e){}
	
		ModelAndView adminBoard = new ModelAndView();

		List<Board> boardList = boardDaoService.getNotices();
        adminBoard.addObject("adminBoard", boardList);
        adminBoard.setViewName("adminBoard");

		return "/admin/adminIndex";
	}
}
