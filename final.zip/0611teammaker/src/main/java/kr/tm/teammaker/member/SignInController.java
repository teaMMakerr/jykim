package kr.tm.teammaker.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.tm.teammaker.dao.MemberDaoService;
import kr.tm.teammaker.vo.Member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class SignInController {

	@Autowired
	private MemberDaoService memberDaoService;

	@RequestMapping(value = "/signIn.do", method = RequestMethod.POST)
	public String signIn(@RequestParam String member_email, @RequestParam String member_password,
			HttpServletRequest req) {

		try {

			String memberemail = req.getParameter("member_email");
			String Admin = "Admin";
			Member member = memberDaoService.selectOne(memberemail, req.getParameter("member_password"));

				if (memberemail.equalsIgnoreCase(Admin)) {
					HttpSession session = req.getSession();
					session.setAttribute("member", member);

					return "adminShowIndex";
				} else {
					HttpSession session = req.getSession();
					session.setAttribute("member", member);

					return "LoginIndex";
				}

			
		}catch (Exception e) {
			return "LoginIndex";
		}
		
	}

}