package kr.tm.teammaker.board;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.tm.teammaker.dao.MemberDaoService;
import kr.tm.teammaker.dao.TMemDaoService;
import kr.tm.teammaker.dao.TeamBoardDaoService;
import kr.tm.teammaker.vo.TeamBoard;
import kr.tm.teammaker.vo.Member;
import kr.tm.teammaker.vo.TMem;

@Controller
public class TeamBoardController {

	@Autowired
	private TeamBoardDaoService teamBoardDaoService;
	@Autowired
	private MemberDaoService memberDaoService;

	@Autowired
	private TMemDaoService tMemDaoService;
	
	

	@RequestMapping(value = "/teamBoard/teamBoardIndex.do", method = RequestMethod.GET)
	public String teamBoardIndex(HttpServletRequest req) {
		return "/teamBoard/teamBoardIndex";
	}

	@RequestMapping(value = "/teamBoard/teamBoard.do", method = RequestMethod.GET)
	public String teamBoard() {
		return "teamBoard";
	}

	@RequestMapping(value = "/teamBoard/teamBoard.do", method = RequestMethod.POST)
	public ModelAndView POSTteamBoard(HttpServletRequest req, Locale locale, Model model) {

		String Bid = req.getParameter("Board_id");
		int Board_id = Integer.parseInt(Bid);
		model.addAttribute("Board_id", Board_id);

		req.setAttribute("Board_id", Board_id);

		String Team_id = req.getParameter("Team_id");


		ModelAndView teamBoard = new ModelAndView();

		List<TeamBoard> boardList = teamBoardDaoService.getNotices(Team_id);
		teamBoard.addObject("teamBoard", boardList);
		teamBoard.setViewName("teamBoard");

		return teamBoard;
	}

	@RequestMapping(value = "/teamBoard/teamBoardNotice.do", method = RequestMethod.GET)
	public String getboardNotice(Locale locale, Model model, HttpServletRequest req) {
		return "/teamBoard/teamBoardNotice.do";
	}

	@RequestMapping(value = "/teamBoard/teamBoardNotice.do", method = RequestMethod.POST)
	public ModelAndView boardNotice(Locale locale, Model model, HttpServletRequest req) throws Exception {


		String myEmail = req.getParameter("myemail");
		
		
		//Team_id ��������!
		String Team_id = tMemDaoService.selectOne(myEmail);
		
		System.out.println(Team_id);


		
			// view ȭ���� main.jsp�� DB�κ��� �о�� �����͸� �����ش�.
			ModelAndView teamBoardNotice = new ModelAndView();

			// addObject view�� �Ѿ�� ������
			List<TeamBoard> boardList = teamBoardDaoService.getNotices(Team_id);
			teamBoardNotice.addObject("teamBoardNotice", boardList);
			teamBoardNotice.setViewName("teamBoardNotice");

			return teamBoardNotice;

	}

	@RequestMapping(value = "/teamBoard/teamBoardList.do", method = RequestMethod.GET)
	public String teamBoardList() {
		return "/teamBoard/teamBoardList";
	}

	@RequestMapping(value = "/teamBoard/teamBoardWrite.do", method = RequestMethod.GET)
	public String teamBoardWrite() {
		return "/teamBoard/teamBoardWrite";
	}

	@RequestMapping(value = "/teamBoard/teamBoardWork.do", method = RequestMethod.GET)
	public String teamBoardWork() {
		return "/teamBoard/teamBoardWork";
	}

}
