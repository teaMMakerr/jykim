package kr.tm.teammaker.member;

import javax.servlet.http.HttpServletRequest;

import kr.tm.teammaker.dao.MemberDaoService;
import kr.tm.teammaker.vo.Member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SignUpController {

	@Autowired
	private MemberDaoService memberDaoService;
	
	@RequestMapping(value = "/sign/signUp.do", method = RequestMethod.GET)
	public String GETsignUp(){
		return "sign/signUp";
	}
	
	@RequestMapping(value = "/sign/signUp.do", method = RequestMethod.POST)
	public String POSTsignUp(HttpServletRequest req) {
		
		try {
		/* email, password, Name, phoneNumber,Tech*/
		Member member= new Member().setMember_email(req.getParameter("email"))
									.setMember_password(req.getParameter("password"))
									.setMember_name(req.getParameter("Name"))
									.setMember_phonenum(req.getParameter("phoneNumber"))
									.setMember_tech(req.getParameter("Tech"));
		
		memberDaoService.insert(member);
		
		return "registerSuccess";
		
		} catch (Exception e ) { System.out.println("signup error  "+e); return "registerSuccess";}
	}
	
}
