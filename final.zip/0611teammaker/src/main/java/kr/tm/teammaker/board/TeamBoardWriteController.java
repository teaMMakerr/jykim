package kr.tm.teammaker.board;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.tm.teammaker.dao.TeamBoardDaoService;
import kr.tm.teammaker.vo.TeamBoard;

@Controller
public class TeamBoardWriteController {
	
	@Autowired
	private TeamBoardDaoService teamBoardDaoService;
		
	@RequestMapping(value = "/teamBoard/teamBoardWrite.do", method = RequestMethod.POST)
	public String POSTboardWrite(HttpServletRequest req) {
		
		try {
	
			
		TeamBoard teamBoard = new TeamBoard();	
		String Team_id = req.getParameter("Team_id");
		String Board_title = req.getParameter("title");
		String Board_context = req.getParameter("context");
		String Member_email = req.getParameter("Member_email");
		String Bid = req.getParameter("Board_id");
		int Board_id = Integer.parseInt(Bid);
		
		
		teamBoardDaoService.insert(teamBoard,Team_id,Board_title,Board_context,Member_email,Board_id);
		
		return "/teamBoard/teamBoardIndex";
		
		} catch (Exception e ) { System.out.println("teamBoardWrite error  "+e); return "/teamBoard/teamBoardIndex";}
	}
	
}
