package kr.tm.teammaker.board;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import kr.tm.teammaker.dao.BoardDaoService;
import kr.tm.teammaker.vo.Board;

@Controller
public class BoardWriteController {

	@Autowired
	private BoardDaoService boardDaoService;

	@RequestMapping(value = "/board/boardWrite.do", method = RequestMethod.POST)
	public String POSTboardWrite(HttpServletRequest req) {

		try {
			
			String Team_id = req.getParameter("Team_id");
			
			Board board = new Board().setBoard_title(req.getParameter("title"))
					.setBoard_context(req.getParameter("context"))
					.setTeam_id(Team_id)
					.setMember_email(req.getParameter("Member_email"));

			boardDaoService.insert(board);

			return "board/boardIndex";

		} catch (Exception e) {
			System.out.println("boardWrite error  " + e);
			return "board/boardIndex";
		}
	}
	
	

}
