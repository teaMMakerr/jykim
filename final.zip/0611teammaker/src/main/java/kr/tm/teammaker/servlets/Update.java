package kr.tm.teammaker.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.tm.teammaker.dao.MemberDao;
import kr.tm.teammaker.vo.Member;

public class Update extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		 RequestDispatcher rd = req.getRequestDispatcher("/auth/update.jsp");
		 rd.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		try {
			req.setCharacterEncoding("utf-8");
			
			ServletContext sc = this.getServletContext();
			MemberDao memberDao = (MemberDao) sc.getAttribute("memberDao");
			
			//Member member = memberDao.update(req.getParameter("phonenum"));
			
		//	req.setAttribute("member", member);

	      resp.sendRedirect("login");
			

		} catch (Exception e) {
			throw new ServletException(e);
		}
	}


}
