package kr.tm.teammaker.dao;

import java.util.ArrayList;

import org.springframework.transaction.annotation.Transactional;

import kr.tm.teammaker.vo.Board;


public interface BoardDao {
	public Board selectOne(int Bid, String email) throws Exception;
	public void insert(Board board)throws Exception;
	public ArrayList<Board> getNotices();
	public void delete(int Board_id)throws Exception;
}
