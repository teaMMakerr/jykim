package kr.tm.teammaker.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.tm.teammaker.vo.Apply;
import kr.tm.teammaker.vo.Board;

@Repository
public class ApplyDaoService implements ApplyDao {
	
	@Autowired
	SqlSession sqlSession;
	
	@Override
	public void insert(String Board_id, String Member_email) {
		
		
		HashMap<String, String> paraMap = new HashMap<String, String>();
		paraMap.put("Board_id", Board_id);
		paraMap.put("Member_email",Member_email);
		
		sqlSession.insert("kr.tm.teammaker.dao.ApplyMapper.insert",paraMap);
		
		
	};
	
	@Override
	public ArrayList<String> selectList(String Board_id){
		
		ArrayList<String> applyMember = new ArrayList<String>();
		
		ApplyMapper mapper = sqlSession.getMapper(ApplyMapper.class);
		applyMember = mapper.selectList(Board_id);
		
		return applyMember;
	};
	
	@Override
    public ArrayList<Apply> getNotices() {
        
		ArrayList<Apply> applyMem = new ArrayList<Apply>();
        //sqlSession�� ���Ͽ� �����Ѵ�.
        ApplyMapper applyMapper = sqlSession.getMapper(ApplyMapper.class);
        //getMember()�� �޼ҵ���� mapper.mxl�� id�� �����ؾ��Ѵ�.
        applyMem = applyMapper.getNotices();
        
        return applyMem;
    }
}
